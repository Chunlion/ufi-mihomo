'use strict';

const fs = require('fs');
const path = require('path');
const vm = require('vm');
const { spawnSync } = require('child_process');

const ROOT = path.resolve(__dirname, '..', '..');
const PLUGIN = path.resolve(ROOT, process.env.F50_PLUGIN || '猫猫TProxy.js');
const source = fs.readFileSync(PLUGIN, 'utf8').replace(/\r\n/g, '\n');
let pass = 0;
let fail = 0;

function check(condition, message, detail = '') {
  if (condition) {
    pass++;
    console.log(`  ✅ ${message}`);
    return;
  }
  fail++;
  console.log(`  ❌ ${message}${detail ? `: ${detail}` : ''}`);
}

function equal(actual, expected, message) {
  const left = JSON.stringify(actual);
  const right = JSON.stringify(expected);
  check(left === right, message, `got=${left} want=${right}`);
}

function slice(start, end) {
  const from = source.indexOf(start);
  const to = source.indexOf(end, from + start.length);
  if (from < 0 || to < 0) throw new Error(`missing source markers: ${start} -> ${end}`);
  return source.slice(from, to);
}

function runBlock(code, context = {}) {
  const sandbox = { console, ...context };
  vm.createContext(sandbox);
  vm.runInContext(code, sandbox, { timeout: 10000 });
  return sandbox;
}

console.log('--- source and package contract ---');
check(fs.existsSync(PLUGIN), '统一插件文件存在');
check(!fs.existsSync(path.join(ROOT, 'MaomaoTProxy_v7.4.5-rc3.js')), '旧 rc3 插件文件已移除');
try {
  new vm.Script(source, { filename: '猫猫TProxy.js' });
  check(true, '插件 JavaScript 语法有效');
} catch (error) {
  check(false, '插件 JavaScript 语法有效', error.message);
}
check(source.includes('猫猫TProxy v9.0.0'), '插件发布版本为 v9.0.0');
check(source.includes("const F50_COMPAT_VERSION = '8.0.0-compat.2.3'"), '前后端兼容版本固定');
check(source.includes('[ -s "$CFG" ] || { f50_install_fail configuration_missing; exit 1; }'), '安装要求初始 config.yaml 存在');
check(source.includes('sh -n "$PKG/Scripts/Clash.Service"'), '安装前校验 Clash.Service 语法');
check(source.includes('f50_install_fail panel_candidate_rejected'), '安装前拒绝错误面板');
check(source.includes('f50_install_fail panel_postcheck_failed'), '替换后再次校验面板');
check(source.includes('F50_ROLLBACK=restored'), '安装失败包含回滚确认');
check(!source.includes('F50 后台单文件上传上限为 10 MiB'), '未保留错误的 10 MiB 组件包提示');
const packageService = spawnSync('tar', ['-xOf', path.join(ROOT, 'tproxy-yq.zip'), 'Scripts/Clash.Service'], { encoding: 'utf8' });
check(packageService.status === 0 && packageService.stdout.includes('drop_detached_tun_rules "$action" || exit 1'), '服务包装器启动前执行 detached TUN 规则兼容清理');
check(packageService.status === 0 && packageService.stdout.includes('disable_unsupported_ipv6_dns_hijack "$@" || exit 1'), '服务包装器启动前执行 IPv6 NAT 能力降级');
check(source.includes('await normalizeIpv6DnsCapability(next)'), '保存网络设置前检查 IPv6 NAT 能力');
check(/rotateClashLogCmd\(\) \+ buildF50MaintenanceFunctions\((?:'start')?\)/.test(source), '启动前轮转过大的核心日志');
check(source.includes("dataSpaceGuardCmd('f50_install_fail data_space_low; exit 1')"), '安装前检查设备可用空间');
check(source.includes("dataSpaceGuardCmd('echo \"ARCHIVE_SPACE_LOW=$kano_data_avail_kb\"; exit 1')"), '在线下载安装包前检查设备可用空间');
check(source.includes('f50_ensure_install_secret || exit 1'), '安装时补全空控制密钥');
check(source.includes('f50_ensure_live_secret'), '启动时补全外部替换配置中的空控制密钥');
check(/mapWithConcurrency\(names,\s*2\s*,/.test(source), '节点来源更新限制并发数');
check(packageService.status === 0 && packageService.stdout.includes('# KANO_DETACHED_TUN_CLEANUP=1'), '组件包服务包装器同步包含兼容清理', packageService.stderr.trim());
check(packageService.status === 0 && packageService.stdout.includes('# KANO_IPV6_NAT_COMPAT=1'), '组件包支持缺少 IPv6 NAT 的设备', packageService.stderr.trim());

console.log('--- Zashboard identity and routing ---');
check(source.includes("const F50_ZASHBOARD_UI_URL = 'https://github.com/Zephyruso/zashboard/releases/latest/download/dist.zip'"), '面板更新源固定为 Zashboard');
check(source.includes("const ZASHBOARD_UI_DIR = 'WebUI/zashboard'"), '面板目录固定为 WebUI/zashboard');
check(source.includes("profile['unified-delay'] = true"), '固定运行配置启用 unified-delay');
check(source.includes("delete config['external-ui-name']"), '固定运行配置删除 external-ui-name');
check(source.includes("/ui/?_f50=${Date.now()}#/"), '面板缓存参数位于 Hash 路由之前');
check(!source.includes('/ui/#/?t='), '旧的无效缓存参数路径已移除');
check(!source.includes('/settings?section=generalSettings'), '没有 MetaCubeXD settings 路由');
const panelValidator = slice('function buildF50ZashboardValidationFunction()', 'function buildF50MaintenanceFunctions(');
check(panelValidator.includes("<title>[[:space:]]*zashboard"), '面板校验要求 Zashboard 标题');
check(panelValidator.includes("wrong_identity"), '面板校验拒绝 MetaCubeXD');
check(!panelValidator.includes('manifest.webmanifest') && !panelValidator.includes('registerSW.js') && panelValidator.includes('missing_main_asset'), '面板校验仅要求身份和实际入口资源');

const dashboardCode = slice('const applyManagedDashboardFields', 'const applyRequiredF50Fields');
const dashboard = runBlock(`${dashboardCode}; this.apply = applyManagedDashboardFields;`, {
  ZASHBOARD_UI_DIR: 'WebUI/zashboard',
  ZASHBOARD_UI_URL: 'https://github.com/Zephyruso/zashboard/releases/latest/download/dist.zip',
  assertYamlRootMap(value) { if (!value || Array.isArray(value) || typeof value !== 'object') throw new Error('not map'); },
});
const managedPanel = { 'external-ui': 'ui', 'external-ui-name': 'zashboard', 'external-ui-url': 'https://example.invalid/ui.zip' };
check(dashboard.apply(managedPanel), '旧托管面板配置会被修正');
equal([managedPanel['external-ui'], managedPanel['external-ui-url'], managedPanel['unified-delay']], [
  'WebUI/zashboard', 'https://github.com/Zephyruso/zashboard/releases/latest/download/dist.zip', true,
], '托管面板字段统一');
check(!Object.hasOwn(managedPanel, 'external-ui-name'), '托管面板不再生成嵌套目录');
const customPanel = { 'external-ui': '/custom/panel', 'external-ui-url': 'https://example.test/custom.zip' };
check(dashboard.apply(customPanel), '自定义面板配置也会被强制修正');
equal([customPanel['external-ui'], customPanel['external-ui-url']], [
  'WebUI/zashboard', 'https://github.com/Zephyruso/zashboard/releases/latest/download/dist.zip',
], '所有配置只允许使用 Zashboard');

console.log('--- generated maintenance shell ---');
const originalServiceSource = slice('const F50_PORTS', 'const F50_ORIGINAL_MANAGED_KEYS')
  + slice('const F50_ORIGINAL_MANAGED_KEYS', 'let f50BackendReady');
const maintenanceSource = originalServiceSource
  + slice('function buildF50ZashboardValidationFunction()', 'function buildF50InspectScript()');
const maintenance = runBlock(`${maintenanceSource}; this.build = buildF50MaintenanceFunctions;`, {
  shellQuote: (value) => `'${String(value).replace(/'/g, `'"'"'`)}'`,
  F50_FILES_DIR: '/data/data/com.minikano.f50_sms/files',
  KANO_INSTALL_TOOLBOX_BIN: '/data/kano_tproxy_tools/bin',
  F50_DEFAULT_SECRET: '123456',
  F50_ZASHBOARD_UI_URL: 'https://github.com/Zephyruso/zashboard/releases/latest/download/dist.zip',
  F50_PORTS: { controller: 7788 },
});
const maintenanceShell = maintenance.build();
const shellSyntax = spawnSync('sh', ['-n'], { input: maintenanceShell, encoding: 'utf8' });
check(shellSyntax.status === 0, '维护和卸载 Shell 通过 sh -n', shellSyntax.stderr && shellSyntax.stderr.trim());
check(maintenanceShell.includes('f50_verify_zashboard_endpoint'), '启动验收包含面板 HTTP 检查');
check(maintenanceShell.includes('http://127.0.0.1:7788/ui/?_f50=$$'), '面板验收请求实际 /ui/ 服务入口');
check(maintenanceShell.includes('echo F50_HEALTH_PANEL=failed') && maintenanceShell.includes("sed 's/^F50_ERROR=/F50_WARNING=/'"), '面板不可访问保留核心启动结果并报告警告');
check(maintenanceShell.includes('arg("iif");arg(d);arg("lookup");arg(t);print "!"'), 'TUN 规则删除只重建受支持字段');
check(!maintenanceShell.includes('for(i=2;i<=NF;i++)arg($i);'), '不把 ip rule 展示注释回放到删除命令');
check(maintenanceShell.includes('f50_drop_detached_tun_rules "$start_action" || return 1'), '启动前先清理 detached TUN 规则');
check(maintenanceShell.includes('if(k=="[detached]")') && maintenanceShell.includes('!foreign && p=="1776"'), 'detached 清理只匹配受管规则字段');
check(maintenanceShell.includes('f50_disable_unsupported_ipv6_dns_hijack || return 1'), '启动前降级不受支持的 IPv6 DNS 劫持');
check(maintenanceShell.includes('F50_START_CODE=secret_ensure_failed'), '控制密钥补全失败时停止启动');
check(maintenanceShell.includes('f50_ensure_live_panel_config'), '每次启动前强制固定 Zashboard 配置');
check(maintenanceShell.includes('F50_START_CODE=panel_config_write_failed'), '面板配置无法固定时拒绝启动');
check(maintenanceShell.includes('F50_ERROR=panel_http_identity_mismatch'), '启动验收拒绝 HTTP 返回 MetaCubeXD 或未知面板');
const installSource = originalServiceSource
  + slice('const rotateClashLogCmd', 'async function installF50PackageAtDevicePath');
const install = runBlock(`${installSource}; this.build = buildF50InstallScript;`, {
  shellQuote: (value) => `'${String(value).replace(/'/g, `'"'"'`)}'`,
  F50_FILES_DIR: '/data/data/com.minikano.f50_sms/files',
  KANO_INSTALL_TOOLBOX_BIN: '/data/kano_tproxy_tools/bin',
  F50_DEFAULT_SECRET: '123456',
  F50_ZASHBOARD_UI_URL: 'https://github.com/Zephyruso/zashboard/releases/latest/download/dist.zip',
  F50_PORTS: { controller: 7788 },
});
const installSyntax = spawnSync('sh', ['-n'], { input: install.build('/data/upload.zip'), encoding: 'utf8' });
check(installSyntax.status === 0, '安装事务 Shell 通过 sh -n', installSyntax.stderr && installSyntax.stderr.trim());
check(install.build('/data/upload.zip').includes('f50_ensure_install_dashboard || exit 1'), '安装和内核升级前强制固定 Zashboard 配置');
const reinstallDir = fs.mkdtempSync(path.join(require('os').tmpdir(), 'f50-reinstall-'));
const quotePath = (value) => `'${String(value).replaceAll(String.fromCharCode(92), '/').replace(/'/g, `'"'"'`)}'`;
try {
  const oldRoot = path.join(reinstallDir, 'clash');
  const stagedRoot = path.join(reinstallDir, 'staged');
  fs.mkdirSync(path.join(oldRoot, 'Tools'), { recursive: true });
  fs.mkdirSync(path.join(oldRoot, 'Proxy'), { recursive: true });
  const original = 'KANO_CONFIG_SOURCE=subscription_original\n';
  fs.writeFileSync(path.join(oldRoot, 'Tools/config_source.conf'), original);
  fs.writeFileSync(path.join(oldRoot, 'Proxy/config.yaml'), 'dns:\n  nameserver: [1.1.1.1]\n');
  const installShell = install.build('/data/upload.zip');
  const from = installShell.indexOf('f50_preserve_user_data() {');
  const to = installShell.indexOf('YQ="$PKG/Tools/yq_linux_arm64"', from);
  const preserved = spawnSync('sh', ['-c', `F50_ROOT=${quotePath(oldRoot)}\nPKG=${quotePath(stagedRoot)}\nf50_install_fail() { return 1; }\n${installShell.slice(from, to)}`], { encoding: 'utf8' });
  check(preserved.status === 0 && fs.readFileSync(path.join(stagedRoot, 'Tools/config_source.conf'), 'utf8') === original,
    '重装同时保留原配置和配置来源标记', preserved.stderr.trim());
  fs.mkdirSync(path.join(oldRoot, 'Scripts'), { recursive: true });
  // The current Service patch restores real preservation helpers, so provide
  // their fixture dependencies instead of relying on overwritten stubs.
  fs.copyFileSync(process.env.F50_TEST_YQ, path.join(oldRoot,'Tools/yq_linux_arm64'));fs.chmodSync(path.join(oldRoot,'Tools/yq_linux_arm64'),0o755);
  fs.writeFileSync(path.join(oldRoot,'Proxy/Clash.Core'),'#!/bin/sh\nexit 0\n',{mode:0o755});
  fs.mkdirSync(path.join(oldRoot,'Policy'));fs.writeFileSync(path.join(oldRoot,'Policy/options.conf'),'traffic_mode=off\nipv6=off\n');
  const service = path.join(oldRoot, 'Scripts/Clash.Service');
  const startLog = path.join(reinstallDir, 'kano_clash_start.log');
  const fixtureBin=path.join(reinstallDir,'bin');fs.mkdirSync(fixtureBin);
  fs.writeFileSync(path.join(fixtureBin,'curl'),'#!/bin/sh\n[ "$1" != --version ] || { echo fixture-curl; exit 0; }\nprintf 204\n',{mode:0o755});
  for (const scenario of ['preflight', 'controller', 'success', 'patch']) {
    const controller = path.join(oldRoot, 'Scripts/clashctl');
    fs.writeFileSync(controller, `#!/bin/sh\n${scenario === 'controller'
      ? "echo F50_ERROR=core_start_failed; echo password=test-start-password; exit 7"
      : 'echo START_STATE=started_verified_process; exit 0'}\n`);
    fs.chmodSync(controller, 0o755);
    fs.writeFileSync(service, scenario === 'patch' ? '#!/bin/sh\nexit 0\n' : packageService.stdout.replace('\naction=$1\n',
      '\nf50_save_original_config() { return 0; }\nf50_restore_original_config() { return 0; }\nrepair_panel_config() { return 0; }\naction=$1\n'));
    const command = `export PATH=${quotePath(fixtureBin)}:$PATH\nF50_ROOT=${quotePath(oldRoot)}\nexport F50_OPERATION_LOCK=${quotePath(path.join(reinstallDir, 'operation.lock'))}\nexport F50_TASK_DIR=${quotePath(path.join(reinstallDir, 'tasks'))}\n${maintenanceShell}
f50_ensure_live_secret() { ${scenario === 'preflight' ? 'echo password=test-start-password; return 1' : 'return 0'}; }
f50_ensure_live_panel_config() { return 0; }
f50_disable_unsupported_ipv6_dns_hijack() { return 0; }
f50_drop_detached_tun_rules() { return 0; }
f50_verify_zashboard_endpoint() { return 0; }
f50_start_service restart 5`;
    const result = spawnSync('sh', ['-s'], { input: command, encoding: 'utf8' });
    const logged = fs.existsSync(startLog) ? fs.readFileSync(startLog, 'utf8') : '';
    check(result.status === (scenario === 'success' ? 0 : 1) && logged === result.stdout &&
      logged.includes(scenario === 'success' ? 'F50_START_OK=1' : 'F50_START_OK=0') &&
      !logged.includes('test-start-password'), `启动 ${scenario} 保留返回状态并保存脱敏日志`, result.stderr.trim()+result.stdout);
    if (scenario === 'patch') check(logged.includes('F50_START_CODE=service_patch_failed') &&
      fs.readFileSync(service, 'utf8') === '#!/bin/sh\nexit 0\n', '包装器补丁失败不覆盖原文件或继续启动');
  }
} finally {
  fs.rmSync(reinstallDir, { recursive: true, force: true });
}

check(source.includes("callMihomoApi('/upgrade/ui', 'POST'"), '面板打开前可通过固定源修复错误面板');
check(source.includes("message: '面板更新结果不是 Zashboard，已阻止加载'"), '在线更新结果身份错误时阻止加载');
const zashboardGuard = slice('const probeZashboardGuard', 'const buildProviderUpdateResult');
check(zashboardGuard.includes('F50_ZASHBOARD_GUARD_OK=1'), '正常面板使用单次快速探针');
check(zashboardGuard.indexOf('if (await probeZashboardGuard()) return') < zashboardGuard.indexOf("readYamlObject(CLASH_CONFIG"), '快速探针通过时不读取和重写 YAML');
check(!zashboardGuard.includes('zashboardNormalizedCorePid'), '新标签页不再因页面内存 PID 为空而热加载配置');
const routePlanDir = fs.mkdtempSync(path.join(ROOT, '.tproxy-route-plan-'));
try {
  const ruleFile = path.join(routePlanDir, 'rules');
  const routeFile = path.join(routePlanDir, 'routes');
  const planFile = path.join(routePlanDir, 'plan');
  fs.writeFileSync(ruleFile, [
    '1776: from all iif KanoTun [detached] lookup 17667 proto static',
    '1777: from all fwmark 0x10000000/0x10000000 lookup 17666 proto static',
    '',
  ].join('\n'));
  fs.writeFileSync(routeFile, '');
  const routePlan = spawnSync('sh', ['-s', '--', ruleFile, routeFile, planFile], { input: `${maintenanceShell}\nf50_routes_plan -4 "$1" "$2" "$3"\ncat "$3"`, encoding: 'utf8' });
  check(routePlan.status === 0 && !routePlan.stdout.includes('[detached]') && routePlan.stdout.includes('aiif\naKanoTun\nalookup\na17667'), '含 [detached] 的 TUN 规则生成可执行删除计划', routePlan.stderr.trim());
  check(!routePlan.stdout.includes('proto') && routePlan.stdout.includes('afwmark\na0x10000000/0x10000000\nalookup\na17666'), 'TProxy 规则同样忽略展示附加字段', routePlan.stderr.trim());
  const compatRoot = path.join(routePlanDir, 'clash');
  const compatBin = path.join(routePlanDir, 'bin');
  fs.mkdirSync(path.join(compatRoot, 'Policy'), { recursive: true });
  fs.mkdirSync(compatBin, { recursive: true });
  const detachedLog = path.join(routePlanDir, 'detached.log');
  fs.writeFileSync(path.join(compatBin, 'ip'), `#!/bin/sh
case "$*" in
  "-4 rule show") echo "1776: from all iif KanoTun [detached] lookup 17667" ;;
  "-6 rule show") ;;
  "-4 rule del pref 1776 iif KanoTun lookup 17667") echo "$*" > "$F50_IP_LOG" ;;
  *) exit 9 ;;
esac
`);
  fs.chmodSync(path.join(compatBin, 'ip'), 0o755);
  const detached = spawnSync('sh', ['-s', '--', compatRoot, compatBin, detachedLog], { input: `${maintenanceShell}
export PATH="$2:$PATH" F50_IP_LOG="$3"
f50_drop_detached_tun_rules
cat "$3"`, encoding: 'utf8' });
  check(detached.status === 0 && detached.stdout.includes('-4 rule del pref 1776 iif KanoTun lookup 17667'), '启动兜底能删除带 [detached] 的 TUN 规则', detached.stderr.trim());
  fs.writeFileSync(path.join(compatRoot, 'Policy', 'options.conf'), 'traffic_mode=tproxy\nipv6=on\ndns_hijack=on\n');
  fs.writeFileSync(path.join(compatBin, 'ip6tables'), '#!/bin/sh\necho "ip6tables: Table does not exist" >&2\nexit 3\n');
  fs.chmodSync(path.join(compatBin, 'ip6tables'), 0o755);
  const compat = spawnSync('sh', ['-s', '--', compatRoot, compatBin], { input: `${maintenanceShell}\nPATH="$2:$PATH" F50_ROOT="$1" f50_disable_unsupported_ipv6_dns_hijack\ncat "$1/Policy/options.conf"`, encoding: 'utf8' });
  check(compat.status === 0 && compat.stdout.includes('F50_WARNING=ipv6_nat_unavailable_ipv4_dns_preserved') && compat.stdout.includes('dns_hijack=on'), '缺少 IPv6 NAT 时保留 DNS 劫持设置', compat.stderr.trim());
  fs.writeFileSync(path.join(compatRoot, 'Policy', 'options.conf'), 'traffic_mode=tproxy\nipv6=on\ndns_hijack=on\n');
  fs.writeFileSync(path.join(compatBin, 'ip6tables'), '#!/bin/sh\necho "xtables lock is busy" >&2\nexit 4\n');
  const transient = spawnSync('sh', ['-s', '--', compatRoot, compatBin], { input: `${maintenanceShell}\nPATH="$2:$PATH" F50_ROOT="$1" f50_disable_unsupported_ipv6_dns_hijack\ncat "$1/Policy/options.conf"`, encoding: 'utf8' });
  check(transient.status === 0 && !transient.stdout.includes('F50_WARNING=') && transient.stdout.includes('dns_hijack=on'), '临时 ip6tables 错误不会关闭 DNS 劫持', transient.stderr.trim());
} finally {
  fs.rmSync(routePlanDir, { recursive: true, force: true });
}
check(source.includes('F50_UNINSTALL_STATE=clean'), '卸载包含最终清洁状态');

console.log('--- subscription sources ---');
const localUrlCode = slice('const isPrivateOrReservedIpv4', 'const getUploadedPath');
const localUrl = runBlock(`${localUrlCode}; this.validate = validateLocalSubscriptionUrl;`, { URL }).validate;
check(localUrl('https://example.com/sub').ok, '本地订阅允许公网 HTTPS 地址');
check(localUrl('http://example.com/sub').ok && localUrl('http://example.com/sub').port === '80', '本地订阅允许公网 HTTP 地址并使用默认端口 80');
check(localUrl('https://example.com/sub').port === '443' && localUrl('http://example.com:8080/sub').port === '8080', '订阅保留 HTTPS 默认端口和 HTTP 自定义端口');
check(!localUrl('ftp://example.com/sub').ok && !localUrl('http://user:pass@example.com/sub').ok, '订阅仍拒绝其他协议和 URL 账号信息');
check(!localUrl('https://127.0.0.1/sub').ok && !localUrl('https://2130706433/sub').ok, '本地订阅拒绝常规和整数形式的回环地址');
check(source.includes('const subUrlChecks = clean.map((source) => ({ source, check: validateLocalSubscriptionUrl(source.url) }))'), '本地转换前校验全部订阅地址');
check(source.includes('const invalidSubSource = cleanSources'), '保存订阅前校验启用地址');
const subscriptionHelpers = slice('const providerNameFor', 'const normalizeSubRuleModeValue');
const providerBuilder = slice('const buildManagedProxyProviders', 'const buildManagedRuleProviders');
const subscriptions = runBlock(`${subscriptionHelpers}\n${providerBuilder}; this.api = { normalizeStoredSubSourceList, normalizeSubSourceList, buildSubUrlsFileText, parseStoredSubSourcesFromText, buildManagedProxyProviders };`, {
  SUB_RULE_MODE_TEMPLATE: 'template',
  SUB_RULE_MODE_ORIGINAL: 'original',
  SUB_CONVERT_MODE_PROVIDER: 'provider',
  SUB_DISABLED_MARKER: '# KANO_DISABLED_SUB=',
  normalizeSubRuleModeValue(value) { return value === 'original' ? 'original' : 'template'; },
  normalizeSubConvertModeValue(value) { return value === 'local' ? 'local' : 'provider'; },
  isHttpUrl(value) { return /^https?:\/\//.test(String(value)); },
  currentProviderUserAgent: 'mihomo',
});
const multipleSources = [
  { url: 'https://one.example/sub', enabled: true },
  { url: 'https://two.example/sub', enabled: true },
  { url: 'https://three.example/sub', enabled: true },
  { url: 'https://four.example/sub', enabled: true },
];
const providers = subscriptions.api.buildManagedProxyProviders(multipleSources);
equal(Object.keys(providers), ['Provider1', 'Provider2', 'Provider3', 'Provider4'], '任意多个订阅按顺序生成 Provider');
equal(Object.values(providers).map((provider) => provider.url), multipleSources.map((item) => item.url), '所有 Provider 保留各自订阅地址');
equal(Object.values(providers).map((provider) => provider.path), [
  './proxies/Provider1.yaml', './proxies/Provider2.yaml', './proxies/Provider3.yaml', './proxies/Provider4.yaml',
], '所有 Provider 使用独立缓存文件');
const storedText = subscriptions.api.buildSubUrlsFileText([...multipleSources, { url: 'https://off.example/sub', enabled: false }]);
check(multipleSources.every((item, index) => storedText.includes(`${item.url} Provider${index + 1}`)), '订阅文件连续命名全部启用来源');
check(storedText.includes('# KANO_DISABLED_SUB=https://off.example/sub'), '订阅文件保留禁用来源');
equal(subscriptions.api.parseStoredSubSourcesFromText(storedText).map((item) => item.enabled), [true, true, true, true, false], '订阅文件可无损读回全部启用状态');
check(source.includes('使用插件本地模板的规则和策略组') && !source.includes('<option value="${SUB_RULE_MODE_ORIGINAL}">'), '界面只提供本地模板模式');

console.log('--- provider groups and traffic modes ---');
const groupsSource = slice('const normalizeManagedProxyGroups', 'const MANAGED_RULE_SET_PATTERN');
const groups = runBlock(`${groupsSource}; this.normalize = normalizeManagedProxyGroups;`, {
  cloneJsonValue: (value) => JSON.parse(JSON.stringify(value)),
  isPlainYamlObject: (value) => !!value && typeof value === 'object' && !Array.isArray(value),
});
const groupConfig = { 'proxy-groups': [{ name: 'Proxy', type: 'select', use: ['Old'] }] };
groups.normalize(groupConfig, ['Provider1', 'Provider2', 'Provider3', 'Provider4']);
equal(groupConfig['proxy-groups'][0].use, ['Provider1', 'Provider2', 'Provider3', 'Provider4'], '策略组同时引用全部 Provider');

const profileSource = slice('const F50_PORTS', 'const F50_COMPAT_VERSION');
const profileApi = runBlock(`${profileSource}; this.profiles = F50_FIXED_PROFILES; this.base = PROFILE_BASE;`, {
  F50_ZASHBOARD_UI_URL: 'https://github.com/Zephyruso/zashboard/releases/latest/download/dist.zip',
});
const profiles = profileApi.profiles;
equal(Object.keys(profiles), ['tproxy4', 'tproxy6', 'tun4', 'tun6', 'off4', 'off6'], '固定配置覆盖三种模式和双栈');
check(Object.values(profiles).every((profile) => profile['external-ui'] === 'WebUI/zashboard'), '所有固定配置使用同一面板目录');
check(profiles.tproxy4.dns !== profiles.tproxy6.dns && profiles.tproxy4.tun !== profiles.tun4.tun, '固定配置深合并后不共享可变对象');
const templateSource = slice('const buildF50TemplateObject', 'const readRuleOverrideConfig');
check(templateSource.includes("'redir-port': 0") && Object.values(profiles).every(profile => profile['redir-port'] === 0), '生成模板与全部运行配置关闭未使用的 Redir 端口');
const kprSource = slice('function createPrivateRouteLogic()', '// SPDX-License-Identifier: AGPL-3.0-or-later');
const kpr = runBlock(`${kprSource}; this.KPR = createPrivateRouteLogic();`, { F50_FIXED_PROFILES: profiles, f50TunStack: profileApi.f50TunStack }).KPR;
const baseConfig = {
  proxies: [],
  'proxy-groups': [{ name: 'Proxy', type: 'select', proxies: ['DIRECT'] }],
  rules: ['MATCH,Proxy'],
};
const tproxy = kpr.runtime(baseConfig, { traffic_mode: 'tproxy', ipv6: 'off' });
equal([tproxy['tproxy-port'], tproxy.tun.enable, tproxy.ipv6], [7895, false, false], 'TProxy IPv4 使用固定端口并关闭 TUN');
const tun = kpr.runtime(baseConfig, { traffic_mode: 'tun', ipv6: 'on' });
check(tun.tun.enable === true && tun.tun.device === 'KanoTun' && tun.ipv6 === true && tun.tun.stack === 'gvisor', 'TUN IPv6 配置完整');
equal(['mixed', 'gvisor', 'system', 'mips'].map(tun_stack => kpr.runtime(baseConfig, { traffic_mode: 'tun', ipv6: 'on', tun_stack }).tun.stack), ['mixed', 'gvisor', 'system', 'mips'], 'TUN 协议栈选择覆盖自动值');
const off = kpr.runtime(baseConfig, { traffic_mode: 'off', ipv6: 'off' });
check(off.tun.enable === false && off['tproxy-port'] === 0, '关闭接管时停用 TUN 和 TProxy');
const privateRoute = kpr.runtime(baseConfig, {
  traffic_mode: 'tproxy', ipv6: 'off', private_route_enabled: 'on',
  private_route_cidrs: '192.168.11.0/24', private_route_policy: 'Proxy',
});
check(privateRoute.rules[0] === 'IP-CIDR,192.168.11.0/24,Proxy,no-resolve', '私网定向代理规则位于规则首部');
check(privateRoute['x-kano-private-route']?.policy === 'Proxy', '私网定向代理写入可回滚元数据');
const tunPrivateRoute = kpr.runtime(baseConfig, {
  traffic_mode: 'tun', ipv6: 'off', private_route_enabled: 'on',
  private_route_cidrs: '192.168.11.0/24', private_route_policy: 'Proxy',
});
const tunExcluded = tunPrivateRoute.tun['route-exclude-address'];
check(tunPrivateRoute['x-kano-private-route']?.mode === 'tun', 'TUN 私网定向代理使用 TUN 整形分支');
check(Array.isArray(tunExcluded) && tunExcluded.includes('10.0.0.0/8') &&
  tunExcluded.every((item) => !kpr.overlaps(kpr.cidr(item), kpr.cidr('192.168.11.0/24'))),
  'TUN 路由排除保留普通私网并放行目标私网');
check(Array.isArray(tunPrivateRoute.tun['dns-hijack']) && tunPrivateRoute.tun['dns-hijack'].length === 0,
  'TUN 私网定向代理不启用核心全局 DNS 劫持');
const backToTproxy = kpr.runtime(tunPrivateRoute, { traffic_mode: 'tproxy', ipv6: 'off' });
check(backToTproxy.tun.enable === false && !backToTproxy['x-kano-private-route'], '从 TUN 切回 TProxy 清理 TUN 私网整形');

const urlGuardSource = slice('const isPrivateOrReservedIpv4', 'const validateLocalSubscriptionUrl');
const urlGuard = runBlock(`${urlGuardSource}; this.isPrivateV4 = isPrivateOrReservedIpv4;`).isPrivateV4;
check(urlGuard('2130706433') && urlGuard('0x7f000001') && !urlGuard('8.8.8.8'), '订阅地址检查识别十进制和十六进制回环地址');

console.log('--- diagnostics and uninstall verdict ---');
const diagnosticSource = slice('let lastInstallDiagnostic', 'async function performF50Uninstall()');
const diagnostics = runBlock(`${diagnosticSource}; this.api = { f50Diagnostic, f50StartResult, f50UninstallVerdict };`, {
  sanitizeSubscriptionSecrets: (value) => String(value),
  buildF50MaintenanceFunctions: () => '',
  shellQuote: (value) => `'${value}'`,
});
const started = diagnostics.api.f50StartResult({ success: true, content: 'START_STATE=started_verified_process\nF50_START_CODE=started\nF50_START_OK=1' });
check(started.ok && started.code === 'started', '启动结果必须包含稳定进程和成功标记');
const panelFailed = diagnostics.api.f50StartResult({ success: true, content: 'F50_ERROR=panel_http_status_404\nF50_START_OK=0\nF50_START_CODE=panel_http_failed' });
check(!panelFailed.ok && panelFailed.code === 'panel_http_failed', '面板 404 不会被报告为启动成功');
const clean = diagnostics.api.f50UninstallVerdict({ content: 'F50_UNINSTALL_STATE=clean\nUNINSTALL_VERIFIED' });
check(clean.ok && clean.code === 'clean', '卸载仅在最终复查干净时成功');
const residual = diagnostics.api.f50UninstallVerdict({ content: 'F50_REMAINS=process:123\nF50_UNINSTALL_STATE=residual' });
check(!residual.ok && residual.code === 'residual', '卸载发现残留时失败');

console.log(`\n================ ${pass} passed / ${fail} failed ================`);
process.exit(fail ? 1 : 0);
